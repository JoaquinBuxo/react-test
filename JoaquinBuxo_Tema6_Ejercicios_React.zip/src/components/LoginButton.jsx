	
export default function LoginButton(props) {
    return (
        <button onClick={props.onClick}>Conectarse</button>
    );
}